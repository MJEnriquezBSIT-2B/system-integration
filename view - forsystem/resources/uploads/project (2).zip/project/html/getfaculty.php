<?php

require_once 'dbconnection.php';

header('Content-Type: application/json');

$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';
$searchCondition = $searchQuery !== '' ? "WHERE fname LIKE '%$searchQuery%' OR lname LIKE '%$searchQuery%'" : '';

// Fetch data from the database with the search condition
$sql = "SELECT * FROM faculty $searchCondition ORDER BY fname";
$result = $conn->query($sql);

// Check if there are results
if ($result->num_rows > 0) {
    // Output data as JSON
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data['faculty'][] = $row;
    }

    // Add total count to the response
    $data['totalFaculty'] = $result->num_rows;

    echo json_encode($data);
} else {
    echo json_encode(array('message' => 'No records found'));
}

// Close the database connection
$conn->close();
?>