<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Update Student</title>
    <link rel="stylesheet" href="style.css" />
    <!-- Add any additional styles or scripts as needed -->
</head>

<body>
    <?php
    
    require_once 'dbconnection.php';

    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
        $studentId = $_GET["id"];

        // Fetch student data
        $sql = "SELECT * FROM students WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $studentId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
    ?>
    <head>
    <meta charset="UTF-8" />
    <title> dashboard pilot design </title>
    <link rel="stylesheet" href="./style.css" />
    <!-- Font Designs -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
</head>

<body>
    <div class="sidebar">
        <div class="logo"></div>
        <ul class="menu">
            <li>
                <a href="dashyyy.html">
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="active">
                <a href="./students.html">
                    <span>Students</span>
                </a>
            </li>
            <li>
                <a href="./faculty.html">
                    <span>Faculty</span>
                </a>
            </li>
            <li>
                <a href="./subjects.html">
                    <span>Subjects</span>
                </a>
            </li>
            <li>
                <a href="./course.html">
                    <span>Course</span>
                </a>
            </li>
            <li>
                <a href="./institute.html">
                    <span>Institute</span>
                </a>
            </li>
            <li class="logout">
                <a href="#">
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <div class="main--content">
        <div class="tabular--wrapper">
            <div>
                <h3 class="main--title">Update Student</h3>
                            <!-- Registration form content goes here -->
                            <div class="main-user-info">
        <form action="updatestudent.php" method="post" id="updateForm">
            <table>
                <tr>
                    <td><label for="upfname">Firstname:</label></td>
                    <td><input type="text" id="upfname" name="upfname" value="<?php echo $row['fname']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="upmname">Middlename:</label></td>
                    <td><input type="text" id="upmname" name="upmname" value="<?php echo $row['mname']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="uplname">Lastname:</label></td>
                    <td><input type="text" id="uplname" name="uplname" value="<?php echo $row['lname']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="upbday">Date of Birth:</label></td>
                    <td><input type="text" id="upbday" name="upbday" value="<?php echo $row['bday']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="upgen">Gender:</label></td>
                    <td><input type="text" id="upgen" name="upgen" value="<?php echo $row['gen']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="upaddress">Home Address:</label></td>
                    <td><input type="text" id="upaddress" name="upaddress" value="<?php echo $row['address']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="upcno">Contact Number:</label></td>
                    <td><input type="text" id="upcno" name="upcno" value="<?php echo $row['cno']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="upinstitute">Institute:</label></td>
                    <td><input type="text" id="upinstitute" name="upinstitute" value="<?php echo $row['institute']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="upcourse">Course:</label></td>
                    <td><input type="text" id="upcourse" name="upcourse" value="<?php echo $row['course']; ?>"></td>
                </tr>
                <tr>
                    <td colspan="2"><strong>Emergency Contact Person:</strong></td>
                </tr>
                <tr>
                    <td><label for="upename">Name of Guardian:</label></td>
                    <td><input type="text" id="upename" name="upename" value="<?php echo $row['ename']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="upecontact">Contact Number:</label></td>
                    <td><input type="text" id="upecontact" name="upecontact" value="<?php echo $row['econtact']; ?>"></td>
                </tr>
                <tr>
                    <td><label for="upeaddress">Address:</label></td>
                    <td><input type="text" id="upeaddress" name="upeaddress" value="<?php echo $row['eaddress']; ?>"></td>
                </tr>
            </table>

            <input type="hidden" name="upid" value="<?php echo $row['id']; ?>">
            <button type="submit">Update</button>
        </form>
    </div>
    </div>
</div>
    <?php
        $stmt->close();
    } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Process the form submission and update the database
        $studentId = $_POST["upid"];
        $fname = $_POST["upfname"];
        $mname = $_POST["upmname"];
        $lname = $_POST["uplname"];
        $bday = $_POST["upbday"];
        $gen = $_POST["upgen"];
        $address = $_POST["upaddress"];
        $cno = $_POST["upcno"];
        $institute = $_POST["upinstitute"];
        $course = $_POST["upcourse"];
        $ename = $_POST["upename"];
        $econtact = $_POST["upecontact"];
        $eaddress = $_POST["upeaddress"];

        // Prepare and execute the SQL query
        $sql = "UPDATE students SET fname=?, mname=?, lname=?, bday=?, gen=?, address=?, cno=?, institute=?, course=?, ename=?, econtact=?, eaddress=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssssi", $fname, $mname, $lname, $bday, $gen, $address, $cno, $institute, $course, $ename, $econtact, $eaddress, $studentId);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Successfully updated
            $response = array('status' => 'success', 'message' => 'Student updated successfully');
            echo json_encode($response);
            header("Location: students.html");
        } else {
            // Failed to update
            $response = array('status' => 'success', 'message' => 'Error updating student');
            echo json_encode($response);
        }

        $stmt->close();
    }
    $conn->close();
    ?>
</body>

</html>
