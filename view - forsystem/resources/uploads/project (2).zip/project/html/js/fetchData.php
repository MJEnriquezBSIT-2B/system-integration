<?php

require_once 'dbconnection.php';

// Fetch count of students based on the 'year' column
$sql = "SELECT year, COUNT(*) AS student_count FROM students GROUP BY year"; 
// Replace 'your_table' with your actual table name

$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the connection
$conn->close();

// Send the data as JSON
echo json_encode($data);
?>