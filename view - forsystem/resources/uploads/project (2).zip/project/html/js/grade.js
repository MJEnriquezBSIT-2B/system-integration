document.addEventListener("DOMContentLoaded", function () {
    // Fetch data from the server and populate the table
    fetchGrades();

    function fetchGrades() {
        // Make an API call to the server to get the grades data
        fetch("/api/getGrades.php")
            .then(response => response.json())
            .then(data => {
                // Populate the table with data
                populateTable(data);
            })
            .catch(error => console.error("Error fetching grades:", error));
    }

    function populateTable(data) {
        const tableBody = document.querySelector("#gradesTable tbody");

        // Clear existing table rows
        tableBody.innerHTML = '';

        // Iterate through the data and create table rows
        data.forEach(student => {
            const row = document.createElement("tr");

            // Add data to the row
            row.innerHTML = `
                <td>${student.student_id}</td>
                <td>${student.student_name}</td>
                <td>${student.grade}</td>
                <td><button onclick="updateGrade(${student.student_id})">Update Grade</button></td>
            `;

            // Append the row to the table
            tableBody.appendChild(row);
        });
    }

    // Function to update grade (you can implement this as needed)
    function updateGrade(studentId) {
        const newGrade = prompt("Enter the new grade:");
        if (newGrade !== null && !isNaN(newGrade)) {
            // Make an API call to update the grade
            fetch("/api/updateGrade.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    studentId: studentId,
                    newGrade: newGrade,
                }),
            })
            .then(response => response.json())
            .then(data => {
                // Handle success or display an error message
                if (data.success) {
                    alert("Grade updated successfully!");
                    // Refresh the table
                    fetchGrades();
                } else {
                    alert("Error updating grade. Please try again.");
                }
            })
            .catch(error => console.error("Error updating grade:", error));
        }
    }
});