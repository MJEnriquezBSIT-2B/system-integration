document.addEventListener('DOMContentLoaded', function () {
    // Function to fetch data from the server
    function fetchData() {
        // Use your server-side script (e.g., PHP) to fetch data from MySQL
        // For this example, we'll use a mock data array
        // Replace this with your actual server-side code to fetch data from MySQL
        return fetch('fetchData.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => data)
            .catch(error => {
                console.error('Error fetching data:', error);
                return [];
            });
    }

    // Function to update the chart with new data
    async function updateChart() {
        // const data = await fetchData(); // Comment out this line
        const data = [
            { year: 2021, student_count: 10 },
            { year: 2022, student_count: 20 },
            // Add more data as needed
        ];

        // Get the canvas element
        const canvas = document.getElementById('canvas').getContext('2d');

        // Destroy the existing chart (if any)
        if (window.myLine) {
            window.myLine.destroy();
        }

        // Create a new line chart
        window.myLine = new Chart(canvas, {
            type: 'line',
            data: {
                labels: data.map(entry => entry.year),
                datasets: [{
                    label: 'Number of Students',
                    borderColor: 'rgb(75, 192, 192)',
                    data: data.map(entry => entry.student_count),
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: 'linear',
                        position: 'bottom'
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // Call the updateChart function
    updateChart();

    // Set up a timer to update the chart periodically (adjust interval as needed)
    setInterval(updateChart, 5000); // Update every 5 seconds (for example)
});