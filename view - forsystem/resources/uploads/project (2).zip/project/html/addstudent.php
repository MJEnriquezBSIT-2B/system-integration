<?php

require_once 'dbconnection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from the request
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $bday = $_POST['bday'];
    $gen = $_POST['gen'];
    $address = $_POST['address'];
    $cno = $_POST['cno'];
    $institute = $_POST['institute'];
    $course = $_POST['course'];
    $ename = $_POST['ename'];
    $econtact = $_POST['econtact'];
    $eaddress = $_POST['eaddress'];

    // SQL query to insert data into the database
    $sql = "INSERT INTO students (fname, mname, lname, bday, gen, address, cno, institute, course, ename, econtact, eaddress)
            VALUES ('$fname', '$mname', '$lname', '$bday', '$gen', '$address', '$cno', '$institute', '$course', '$ename', '$econtact', '$eaddress')";

    if ($conn->query($sql) === TRUE) {
        $response = array('status' => 'success', 'message' => 'Student added successfully');
        echo json_encode($response);
    } else {
        $response = array('status' => 'error', 'message' => 'Error adding student: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    // Handle invalid request method
    $response = array('status' => 'error', 'message' => 'Invalid request method');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>