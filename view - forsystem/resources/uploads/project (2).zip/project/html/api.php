<?php

header('Content-Type: application/json');

// Database connection
require_once 'dbconnection.php';

$instituteName = $_GET['institute'];

// Query to get total students for the specified institute
$query = "SELECT COUNT(*) as totalStudents FROM students WHERE institute = '$instituteName'";
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $totalStudents = $row['totalStudents'];

    // Return total students in JSON format
    echo json_encode(['totalStudents' => $totalStudents]);
} else {
    echo json_encode(['error' => 'Error fetching data']);
}

// Close the database connection
mysqli_close($conn);
?>