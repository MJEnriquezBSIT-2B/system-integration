// script.js
function openPopup() {
    const popup = document.getElementById('registrationPopup');
    popup.style.display = 'block';
}

function submitForm() {
    const form = document.getElementById('registrationForm');
    const formData = new FormData(form);

    // Use AJAX (e.g., fetch API) to send data to the RESTful API endpoint
    fetch('https://your-api-endpoint.com/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(Object.fromEntries(formData)),
    })
    .then(response => response.json())
    .then(data => {
        // Handle the API response
        console.log(data);
        // You can close the popup or redirect the user after successful registration
        closePopup();
    })
    .catch(error => console.error('Error:', error));
}

function closePopup() {
    const popup = document.getElementById('registrationPopup');
    popup.style.display = 'none';
}