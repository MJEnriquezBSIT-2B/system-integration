<?php

require_once 'dbconnection.php';

header('Content-Type: application/json');

// Check if the request method is DELETE
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Retrieve student ID from the request
    $studentId = $_GET['id'];

    // SQL query to delete the student record
    $sql = "DELETE FROM students WHERE id = $studentId";

    if ($conn->query($sql) === TRUE) {
        $response = array('status' => 'success', 'message' => 'Student deleted successfully');
        echo json_encode($response);
    } else {
        $response = array('status' => 'error', 'message' => 'Error deleting student: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    // Handle invalid request method
    $response = array('status' => 'error', 'message' => 'Invalid request method');
    echo json_encode($response);
}

// Close the database connection
$conn->close();

?>