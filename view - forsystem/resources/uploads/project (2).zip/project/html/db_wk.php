<?php
require_once 'dbconnection.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $fname = $_POST["fname"];
    $mname = $_POST["mname"];
    $lname = $_POST["lname"];
    $bday = $_POST["bday"];
    $fname = $_POST["fname"];
    $gen = $_POST["gen"];
    $address = $_POST["address"];
    $cno = $_POST["cno"];
    $institute = $_POST["institute"];
    $course = $_POST["course"];
}


?>