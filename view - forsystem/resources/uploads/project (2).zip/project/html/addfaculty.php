<?php

require_once 'dbconnection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from the request
    $lname = $_POST['lname'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $bday = $_POST['bday'];
    $gen = $_POST['gen'];
    $institute = $_POST['institute'];
    $course = $_POST['course'];
    $cno = $_POST['cno'];

    // SQL query to insert data into the database
    $sql = "INSERT INTO faculty (lname, fname, mname, bday, gen, institute, course, cno)
            VALUES ('$lname', '$fname', '$mname', '$bday', '$gen', '$institute', '$course', '$cno')";

    if ($conn->query($sql) === TRUE) {
        $response = array('status' => 'success', 'message' => 'Student added successfully');
        echo json_encode($response);
    } else {
        $response = array('status' => 'error', 'message' => 'Error adding student: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    // Handle invalid request method
    $response = array('status' => 'error', 'message' => 'Invalid request method');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>